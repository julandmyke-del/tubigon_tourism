import { useState, useEffect, useRef } from 'react'
import {
  LayoutDashboard, Store, List, Plus, Edit3, Image, Calendar, Star,
  BarChart3, Tag, Bell, FileText, Clock, Settings, HelpCircle,
  LogOut, ChevronRight, Search, Menu, X, TrendingUp, TrendingDown,
  Users, DollarSign, Eye, ShoppingBag, CheckCircle, XCircle, Clock3,
  AlertCircle, Filter, Download, Upload, Trash2, MoreVertical,
  MapPin, Phone, Globe, Mail,
  ChevronLeft, ChevronDown, RefreshCw, ExternalLink, Copy,
  ThumbsUp, MessageSquare, Award, Zap, Target, Activity,
  PieChart, ArrowUpRight, ArrowDownRight, Bookmark, Package,
  Camera, Grid, Layers, Info, Shield, Key, CreditCard, Percent,
} from 'lucide-react'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart as RechartsPie,
  Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Legend,
} from 'recharts'

// ─── Types ───────────────────────────────────────────────────────────────────
type Page =
  | 'dashboard' | 'profile' | 'listings' | 'add-listing' | 'edit-listing'
  | 'gallery' | 'reservations' | 'reviews' | 'analytics' | 'promotions'
  | 'notifications' | 'reports' | 'calendar' | 'settings' | 'help'

interface NavItem {
  id: Page
  label: string
  icon: React.ReactNode
  badge?: number
}

// ─── Constants ────────────────────────────────────────────────────────────────
const ORANGE = '#f97316'
const ORANGE_DARK = '#ea580c'
const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
  { id: 'profile', label: 'Business Profile', icon: <Store size={18} /> },
  { id: 'listings', label: 'My Listings', icon: <List size={18} /> },
  { id: 'gallery', label: 'Gallery Manager', icon: <Image size={18} /> },
  { id: 'reservations', label: 'Reservations', icon: <Calendar size={18} />, badge: 3 },
  { id: 'reviews', label: 'Customer Reviews', icon: <Star size={18} /> },
  { id: 'analytics', label: 'Business Analytics', icon: <BarChart3 size={18} /> },
  { id: 'promotions', label: 'Promotions', icon: <Tag size={18} /> },
  { id: 'notifications', label: 'Notifications', icon: <Bell size={18} />, badge: 5 },
  { id: 'reports', label: 'Reports', icon: <FileText size={18} /> },
  { id: 'calendar', label: 'Availability', icon: <Clock size={18} /> },
  { id: 'settings', label: 'Settings', icon: <Settings size={18} /> },
  { id: 'help', label: 'Help Center', icon: <HelpCircle size={18} /> },
]

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatCard({
  title, value, subtitle, icon, trend, trendValue, color = ORANGE, delay = 0,
}: {
  title: string; value: string | number; subtitle?: string
  icon: React.ReactNode; trend?: 'up' | 'down' | 'neutral'; trendValue?: string
  color?: string; delay?: number
}) {
  return (
    <div
      className="stat-card glass-card rounded-2xl p-5 animate-fade-in-up"
      style={{ animationDelay: `${delay}ms`, border: '1px solid rgba(255,255,255,0.07)' }}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-11 h-11 rounded-xl flex items-center justify-center"
          style={{ background: `${color}1a`, color }}
        >
          {icon}
        </div>
        {trend && trendValue && (
          <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-lg ${
            trend === 'up' ? 'bg-green-500/10 text-green-400' :
            trend === 'down' ? 'bg-red-500/10 text-red-400' :
            'bg-slate-500/10 text-slate-400'
          }`}>
            {trend === 'up' ? <ArrowUpRight size={12} /> : trend === 'down' ? <ArrowDownRight size={12} /> : null}
            {trendValue}
          </div>
        )}
      </div>
      <div className="text-2xl font-bold text-white mb-1" style={{ fontFamily: "'DM Sans', sans-serif" }}>
        {value}
      </div>
      <div className="text-sm font-medium text-slate-300">{title}</div>
      {subtitle && <div className="text-xs text-slate-500 mt-1">{subtitle}</div>}
    </div>
  )
}

function SectionHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div>
        <h2 className="text-xl font-bold text-white" style={{ fontFamily: "'DM Sans', sans-serif" }}>{title}</h2>
        {subtitle && <p className="text-sm text-slate-400 mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}

function Badge({ type, label }: { type: 'success' | 'warning' | 'error' | 'info' | 'orange' | 'gray'; label: string }) {
  return <span className={`badge badge-${type}`}>{label}</span>
}

function Btn({
  children, variant = 'primary', size = 'md', onClick, className = '', icon, disabled,
}: {
  children: React.ReactNode; variant?: 'primary' | 'ghost' | 'danger'
  size?: 'sm' | 'md' | 'lg'; onClick?: () => void; className?: string
  icon?: React.ReactNode; disabled?: boolean
}) {
  const sz = size === 'sm' ? 'px-3 py-1.5 text-xs' : size === 'lg' ? 'px-6 py-3 text-base' : 'px-4 py-2 text-sm'
  const base = `ripple inline-flex items-center gap-2 font-semibold rounded-xl cursor-pointer border-0 ${sz} ${className}`
  const v = variant === 'primary' ? 'btn-primary' : variant === 'danger'
    ? 'bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-colors'
    : 'btn-ghost'
  return (
    <button className={`${base} ${v}`} onClick={onClick} disabled={disabled}>
      {icon && <span className="flex-shrink-0">{icon}</span>}
      {children}
    </button>
  )
}

function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`glass-card rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  )
}

function Input({
  label, type = 'text', placeholder, value, onChange, icon, required,
}: {
  label?: string; type?: string; placeholder?: string; value?: string
  onChange?: (v: string) => void; icon?: React.ReactNode; required?: boolean
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">
          {label}{required && <span className="text-orange-400 ml-1">*</span>}
        </label>
      )}
      <div className="relative">
        {icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">{icon}</span>}
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={e => onChange?.(e.target.value)}
          className={`w-full py-2.5 text-sm ${icon ? 'pl-10' : 'pl-3'} pr-3`}
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }}
        />
      </div>
    </div>
  )
}

function Select({ label, options, value, onChange }: {
  label?: string; options: { label: string; value: string }[]
  value?: string; onChange?: (v: string) => void
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{label}</label>}
      <select
        value={value}
        onChange={e => onChange?.(e.target.value)}
        className="py-2.5 px-3 text-sm appearance-none"
        style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }}
      >
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  )
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
function Sidebar({ current, onNav, collapsed, onToggle }: {
  current: Page; onNav: (p: Page) => void; collapsed: boolean; onToggle: () => void
}) {
  return (
    <aside
      className="flex flex-col h-full select-none"
      style={{ background: 'var(--sidebar-bg)', borderRight: '1px solid var(--sidebar-border)', width: collapsed ? 64 : 240, transition: 'width 0.3s ease', flexShrink: 0 }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5" style={{ borderBottom: '1px solid var(--sidebar-border)', minHeight: 68 }}>
        <div
          className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: 'linear-gradient(135deg, #f97316, #ea580c)' }}
        >
          <Store size={18} color="white" />
        </div>
        {!collapsed && (
          <div className="animate-fade-in overflow-hidden">
            <div className="text-sm font-bold text-white leading-tight">Tubigon STIMS</div>
            <div className="text-xs text-orange-400 font-medium">MSME Owner</div>
          </div>
        )}
        <button
          onClick={onToggle}
          className="ml-auto p-1 rounded-lg hover:bg-white/5 text-slate-500 hover:text-slate-300 transition-colors"
        >
          {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>
      </div>

      {/* Business info */}
      {!collapsed && (
        <div className="px-4 py-3 animate-fade-in" style={{ borderBottom: '1px solid var(--sidebar-border)' }}>
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, #7c3aed, #4f46e5)' }}
            >JD</div>
            <div>
              <div className="text-xs font-semibold text-white leading-tight">Juan's Seafood Place</div>
              <div className="flex items-center gap-1 mt-0.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400"></div>
                <span className="text-xs text-green-400">Verified</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-2 px-2">
        {NAV_ITEMS.map(item => (
          <button
            key={item.id}
            onClick={() => onNav(item.id)}
            className={`sidebar-item w-full flex items-center gap-3 px-3 py-2.5 rounded-xl mb-0.5 text-left ${current === item.id ? 'active' : ''}`}
            style={{ color: current === item.id ? ORANGE : '#94a3b8' }}
            title={collapsed ? item.label : undefined}
          >
            <span className="nav-icon flex-shrink-0">{item.icon}</span>
            {!collapsed && (
              <span className="text-sm font-medium flex-1 animate-fade-in">{item.label}</span>
            )}
            {!collapsed && item.badge && (
              <span
                className="text-xs font-bold px-1.5 py-0.5 rounded-full animate-fade-in"
                style={{ background: 'rgba(249,115,22,0.2)', color: ORANGE, minWidth: 20, textAlign: 'center' }}
              >{item.badge}</span>
            )}
            {collapsed && item.badge && (
              <span
                className="absolute right-1 top-1 w-2 h-2 rounded-full notification-dot"
                style={{ background: ORANGE }}
              />
            )}
          </button>
        ))}
      </nav>

      {/* Logout */}
      <div className="p-2" style={{ borderTop: '1px solid var(--sidebar-border)' }}>
        <button
          className="sidebar-item w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left"
          style={{ color: '#ef4444' }}
          title={collapsed ? 'Logout' : undefined}
        >
          <LogOut size={18} />
          {!collapsed && <span className="text-sm font-medium animate-fade-in">Logout</span>}
        </button>
      </div>
    </aside>
  )
}

// ─── App Bar ──────────────────────────────────────────────────────────────────
function AppBar({ page, onMobileMenu, notifCount = 5 }: { page: Page; onMobileMenu: () => void; notifCount?: number }) {
  const labels: Record<Page, string> = {
    dashboard: 'Dashboard', profile: 'Business Profile', listings: 'My Listings',
    'add-listing': 'Add Listing', 'edit-listing': 'Edit Listing', gallery: 'Gallery Manager',
    reservations: 'Reservation Management', reviews: 'Customer Reviews', analytics: 'Business Analytics',
    promotions: 'Promotions & Discounts', notifications: 'Notifications', reports: 'Reports',
    calendar: 'Availability Calendar', settings: 'Settings', help: 'Help Center',
  }
  const breadcrumbs: Record<Page, string[]> = {
    dashboard: ['MSME', 'Dashboard'], profile: ['MSME', 'Business Profile'],
    listings: ['MSME', 'Listings'], 'add-listing': ['MSME', 'Listings', 'Add'],
    'edit-listing': ['MSME', 'Listings', 'Edit'], gallery: ['MSME', 'Gallery'],
    reservations: ['MSME', 'Reservations'], reviews: ['MSME', 'Reviews'],
    analytics: ['MSME', 'Analytics'], promotions: ['MSME', 'Promotions'],
    notifications: ['MSME', 'Notifications'], reports: ['MSME', 'Reports'],
    calendar: ['MSME', 'Calendar'], settings: ['MSME', 'Settings'], help: ['MSME', 'Help'],
  }

  return (
    <header
      className="flex items-center gap-4 px-6 py-4 flex-shrink-0"
      style={{
        background: 'rgba(8,13,26,0.85)', backdropFilter: 'blur(20px)',
        borderBottom: '1px solid rgba(255,255,255,0.06)', position: 'sticky', top: 0, zIndex: 10,
      }}
    >
      <button className="lg:hidden p-2 rounded-lg hover:bg-white/5 text-slate-400" onClick={onMobileMenu}>
        <Menu size={18} />
      </button>
      <div className="flex-1 min-w-0">
        <h1 className="text-lg font-bold text-white truncate" style={{ fontFamily: "'DM Sans', sans-serif" }}>
          {labels[page]}
        </h1>
        <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
          {breadcrumbs[page].map((b, i) => (
            <span key={i} className="flex items-center gap-1">
              {i > 0 && <ChevronRight size={10} />}
              <span className={i === breadcrumbs[page].length - 1 ? 'text-orange-400' : ''}>{b}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Search */}
      <div className="relative hidden md:block">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          placeholder="Search anything..."
          className="pl-9 pr-4 py-2 text-sm w-56 rounded-xl"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', color: '#f1f5f9' }}
        />
      </div>

      {/* Notifications */}
      <button className="relative p-2 rounded-xl hover:bg-white/5 text-slate-400 hover:text-white transition-colors">
        <Bell size={18} />
        {notifCount > 0 && (
          <span
            className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full text-xs font-bold flex items-center justify-center"
            style={{ background: ORANGE, color: 'white' }}
          >{notifCount}</span>
        )}
      </button>

      {/* Avatar */}
      <div className="flex items-center gap-2.5 cursor-pointer group">
        <div
          className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold text-white flex-shrink-0"
          style={{ background: 'linear-gradient(135deg, #7c3aed, #4f46e5)' }}
        >JD</div>
        <div className="hidden md:block">
          <div className="text-sm font-semibold text-white">Juan Dela Cruz</div>
          <div className="text-xs text-slate-500">msme_owner</div>
        </div>
        <ChevronDown size={14} className="text-slate-500 hidden md:block" />
      </div>
    </header>
  )
}

// ─── Pages ────────────────────────────────────────────────────────────────────

const revenueData = [
  { month: 'Jan', revenue: 12400, bookings: 24 },
  { month: 'Feb', revenue: 14800, bookings: 31 },
  { month: 'Mar', revenue: 11200, bookings: 22 },
  { month: 'Apr', revenue: 17600, bookings: 38 },
  { month: 'May', revenue: 19800, bookings: 45 },
  { month: 'Jun', revenue: 22100, bookings: 52 },
  { month: 'Jul', revenue: 24500, bookings: 58 },
  { month: 'Aug', revenue: 21300, bookings: 48 },
]

const reviewDist = [
  { name: '5 Stars', value: 45, color: '#22c55e' },
  { name: '4 Stars', value: 28, color: '#84cc16' },
  { name: '3 Stars', value: 15, color: '#eab308' },
  { name: '2 Stars', value: 8, color: '#f97316' },
  { name: '1 Star', value: 4, color: '#ef4444' },
]

const trafficData = [
  { day: 'Mon', views: 120, clicks: 45 },
  { day: 'Tue', views: 180, clicks: 72 },
  { day: 'Wed', views: 140, clicks: 58 },
  { day: 'Thu', views: 220, clicks: 89 },
  { day: 'Fri', views: 290, clicks: 110 },
  { day: 'Sat', views: 380, clicks: 145 },
  { day: 'Sun', views: 260, clicks: 98 },
]

function DashboardPage({ onNav }: { onNav: (p: Page) => void }) {
  return (
    <div className="page-transition space-y-6">
      {/* Business Banner */}
      <div
        className="rounded-2xl p-6 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #0e1628 0%, #1a2540 50%, #0e1628 100%)', border: '1px solid rgba(249,115,22,0.2)' }}
      >
        <div className="absolute top-0 right-0 w-64 h-64 opacity-5" style={{ background: `radial-gradient(circle, ${ORANGE}, transparent 70%)` }} />
        <div className="flex items-center gap-4 relative">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold text-white flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #7c3aed, #4f46e5)', boxShadow: '0 8px 24px rgba(124,58,237,0.4)' }}
          >JS</div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl font-bold text-white" style={{ fontFamily: "'DM Sans', sans-serif" }}>Juan's Seafood Place</h2>
              <span className="badge badge-success">Verified</span>
            </div>
            <div className="flex items-center gap-4 text-sm text-slate-400">
              <span className="flex items-center gap-1"><MapPin size={12} /> Tubigon, Bohol</span>
              <span className="flex items-center gap-1"><Star size={12} className="text-yellow-400" /> 4.7 (89 reviews)</span>
              <span className="flex items-center gap-1"><Eye size={12} /> 1,245 views this month</span>
            </div>
          </div>
          <div className="ml-auto hidden md:flex gap-2">
            <Btn variant="ghost" size="sm" icon={<Edit3 size={14} />} onClick={() => onNav('profile')}>Edit Profile</Btn>
            <Btn size="sm" icon={<ExternalLink size={14} />}>View Listing</Btn>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Revenue" value="₱143,800" subtitle="This month" icon={<DollarSign size={20} />} trend="up" trendValue="+12.4%" delay={0} />
        <StatCard title="Reservations" value="58" subtitle="Active bookings" icon={<Calendar size={20} />} trend="up" trendValue="+8.2%" color="#3b82f6" delay={60} />
        <StatCard title="Avg. Rating" value="4.7" subtitle="From 89 reviews" icon={<Star size={20} />} trend="up" trendValue="+0.2" color="#eab308" delay={120} />
        <StatCard title="Total Views" value="1,245" subtitle="Profile visits" icon={<Eye size={20} />} trend="down" trendValue="-3.1%" color="#22c55e" delay={180} />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <SectionHeader title="Revenue Overview" subtitle="Monthly revenue & booking trends" />
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={ORANGE} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={ORANGE} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="month" stroke="#475569" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis stroke="#475569" tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip contentStyle={{ background: '#0e1628', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }} />
              <Area type="monotone" dataKey="revenue" stroke={ORANGE} fill="url(#revGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Review Distribution" subtitle="Rating breakdown" />
          <ResponsiveContainer width="100%" height={160}>
            <RechartsPie>
              <Pie data={reviewDist} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                {reviewDist.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip contentStyle={{ background: '#0e1628', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }} />
            </RechartsPie>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {reviewDist.map(r => (
              <div key={r.name} className="flex items-center gap-2 text-xs">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: r.color }} />
                <span className="text-slate-400 flex-1">{r.name}</span>
                <span className="font-semibold text-white">{r.value}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Activity + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <SectionHeader title="Recent Reservations" subtitle="Latest booking activity"
            action={<Btn size="sm" variant="ghost" onClick={() => onNav('reservations')}>View All</Btn>} />
          <div className="space-y-0">
            {[
              { name: 'Maria Santos', service: 'Seafood Platter for 4', date: 'Aug 3, 2026', amount: '₱2,400', status: 'confirmed' },
              { name: 'Jose Reyes', service: 'Private Dining Room', date: 'Aug 4, 2026', amount: '₱4,800', status: 'pending' },
              { name: 'Ana Lim', service: 'Bangus Festival Package', date: 'Aug 5, 2026', amount: '₱1,800', status: 'confirmed' },
              { name: 'Carlo Mendoza', service: 'Seafood Platter for 2', date: 'Aug 6, 2026', amount: '₱1,600', status: 'cancelled' },
            ].map((r, i) => (
              <div key={i} className="table-row flex items-center gap-4 py-3 border-b last:border-b-0" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                  style={{ background: `hsl(${i * 60 + 200}, 60%, 40%)` }}
                >{r.name[0]}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white truncate">{r.name}</div>
                  <div className="text-xs text-slate-500 truncate">{r.service}</div>
                </div>
                <div className="text-right hidden sm:block">
                  <div className="text-sm font-semibold text-white">{r.amount}</div>
                  <div className="text-xs text-slate-500">{r.date}</div>
                </div>
                <Badge type={r.status === 'confirmed' ? 'success' : r.status === 'pending' ? 'warning' : 'error'} label={r.status} />
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <h3 className="text-sm font-bold text-white mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'Add Listing', icon: <Plus size={16} />, page: 'add-listing' as Page },
                { label: 'New Promo', icon: <Tag size={16} />, page: 'promotions' as Page },
                { label: 'View Reports', icon: <FileText size={16} />, page: 'reports' as Page },
                { label: 'Availability', icon: <Clock size={16} />, page: 'calendar' as Page },
              ].map(a => (
                <button
                  key={a.label}
                  onClick={() => onNav(a.page)}
                  className="flex flex-col items-center gap-2 p-3 rounded-xl text-center ripple transition-all hover:-translate-y-0.5"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
                >
                  <span className="text-orange-400">{a.icon}</span>
                  <span className="text-xs font-medium text-slate-300">{a.label}</span>
                </button>
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="text-sm font-bold text-white mb-3">Business Score</h3>
            <div className="flex items-center gap-3 mb-4">
              <div className="text-3xl font-bold text-white" style={{ fontFamily: "'DM Sans', sans-serif" }}>87</div>
              <div>
                <Badge type="success" label="Excellent" />
                <div className="text-xs text-slate-500 mt-1">out of 100</div>
              </div>
            </div>
            {[
              { label: 'Profile Completion', pct: 90 },
              { label: 'Response Rate', pct: 82 },
              { label: 'Review Score', pct: 94 },
              { label: 'Listing Quality', pct: 78 },
            ].map(m => (
              <div key={m.label} className="mb-3">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">{m.label}</span>
                  <span className="text-slate-300 font-medium">{m.pct}%</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${m.pct}%` }} />
                </div>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  )
}

function BusinessProfilePage() {
  const [editMode, setEditMode] = useState(false)
  return (
    <div className="page-transition space-y-6">
      {/* Verification Banner */}
      <div
        className="rounded-2xl p-4 flex items-center gap-3"
        style={{ background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.2)' }}
      >
        <CheckCircle size={20} className="text-green-400 flex-shrink-0" />
        <div className="flex-1">
          <span className="text-sm font-semibold text-green-400">Business Verified</span>
          <span className="text-sm text-slate-400 ml-2">Your business is verified and visible to tourists.</span>
        </div>
        <Badge type="success" label="DTI Registered" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <Card>
          <div className="text-center">
            <div
              className="w-24 h-24 rounded-2xl flex items-center justify-center text-4xl font-bold text-white mx-auto mb-4"
              style={{ background: 'linear-gradient(135deg, #7c3aed, #4f46e5)', boxShadow: '0 8px 32px rgba(124,58,237,0.4)' }}
            >JS</div>
            <div className="text-lg font-bold text-white mb-1">Juan's Seafood Place</div>
            <div className="text-sm text-slate-400 mb-3">Local Restaurant & Seafood</div>
            <div className="flex justify-center gap-2 mb-4">
              <Badge type="success" label="Verified" />
              <Badge type="info" label="Featured" />
            </div>
            <button className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#f1f5f9' }}>
              <Camera size={14} /> Change Logo
            </button>
          </div>

          <div className="mt-5 space-y-3 pt-5" style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <Star size={14} className="text-yellow-400" /> <span className="text-white font-medium">4.7</span> avg rating (89 reviews)
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <Eye size={14} className="text-blue-400" /> <span className="text-white font-medium">1,245</span> profile views this month
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <Package size={14} className="text-orange-400" /> <span className="text-white font-medium">8</span> active listings
            </div>
          </div>
        </Card>

        {/* Business Info */}
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-base font-bold text-white">Business Information</h3>
              <p className="text-xs text-slate-500 mt-0.5">Keep your business details accurate for tourists</p>
            </div>
            <Btn size="sm" variant={editMode ? 'primary' : 'ghost'} icon={<Edit3 size={14} />} onClick={() => setEditMode(!editMode)}>
              {editMode ? 'Save Changes' : 'Edit Info'}
            </Btn>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Business Name" value="Juan's Seafood Place" />
            <Select label="Category" options={[
              { label: 'Restaurant', value: 'restaurant' },
              { label: 'Souvenir Shop', value: 'souvenir' },
              { label: 'Tour Operator', value: 'tour' },
              { label: 'Accommodation', value: 'accommodation' },
            ]} value="restaurant" />
            <Input label="Phone Number" value="+63 912 345 6789" icon={<Phone size={14} />} />
            <Input label="Email Address" value="jdelacuz@gmail.com" icon={<Mail size={14} />} />
            <Input label="Website" value="https://juansseafood.ph" icon={<Globe size={14} />} />
            <Input label="Address" value="Purok 3, Poblacion, Tubigon, Bohol" icon={<MapPin size={14} />} />
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide block mb-1.5">Business Description</label>
              <textarea
                rows={3}
                defaultValue="Fresh seafood caught daily from the Bohol Sea. We offer a wide variety of local seafood dishes prepared using traditional Boholano recipes. Perfect for families and groups."
                className="w-full px-3 py-2.5 text-sm resize-none"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }}
              />
            </div>
          </div>

          <div className="mt-5 pt-5 border-t" style={{ borderColor: 'rgba(255,255,255,0.07)' }}>
            <h4 className="text-sm font-bold text-white mb-3">Social Media Links</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Input label="Facebook" placeholder="facebook.com/..." icon={<Globe size={14} />} />
              <Input label="Instagram" placeholder="@username" icon={<Globe size={14} />} />
              <Input label="Twitter / X" placeholder="@username" icon={<Globe size={14} />} />
            </div>
          </div>

          <div className="mt-5 pt-5 border-t" style={{ borderColor: 'rgba(255,255,255,0.07)' }}>
            <h4 className="text-sm font-bold text-white mb-3">Operating Hours</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {['Mon–Fri', 'Saturday', 'Sunday', 'Holidays'].map((d, i) => (
                <div key={d}>
                  <div className="text-xs text-slate-500 mb-1">{d}</div>
                  <div
                    className="py-2 px-3 rounded-lg text-xs text-white font-medium"
                    style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                  >{i < 2 ? '7:00 AM – 9:00 PM' : i === 2 ? '8:00 AM – 8:00 PM' : 'Closed'}</div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Verification Documents */}
      <Card>
        <SectionHeader title="Verification Documents" subtitle="Required documents for business verification" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'DTI Registration', status: 'verified', file: 'DTI_Cert_2026.pdf' },
            { label: 'Barangay Clearance', status: 'verified', file: 'Brgy_Clearance.pdf' },
            { label: "Mayor's Permit", status: 'pending', file: 'Upload required' },
            { label: 'Sanitary Permit', status: 'expired', file: 'Upload required' },
          ].map(d => (
            <div
              key={d.label}
              className="rounded-xl p-4"
              style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}
            >
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${
                d.status === 'verified' ? 'bg-green-500/10' : d.status === 'pending' ? 'bg-yellow-500/10' : 'bg-red-500/10'
              }`}>
                {d.status === 'verified' ? <CheckCircle size={18} className="text-green-400" /> :
                 d.status === 'pending' ? <Clock3 size={18} className="text-yellow-400" /> :
                 <XCircle size={18} className="text-red-400" />}
              </div>
              <div className="text-xs font-semibold text-white mb-1">{d.label}</div>
              <div className="text-xs text-slate-500 mb-2">{d.file}</div>
              <Badge type={d.status === 'verified' ? 'success' : d.status === 'pending' ? 'warning' : 'error'} label={d.status} />
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}

function ListingsPage({ onNav }: { onNav: (p: Page) => void }) {
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const listings = [
    { id: 1, name: 'Seafood Platter for 2', category: 'Food Package', price: '₱1,600', status: 'active', views: 342, bookings: 18 },
    { id: 2, name: 'Seafood Platter for 4', category: 'Food Package', price: '₱2,800', status: 'active', views: 589, bookings: 32 },
    { id: 3, name: 'Private Dining Room', category: 'Venue', price: '₱4,800', status: 'active', views: 210, bookings: 9 },
    { id: 4, name: 'Bangus Festival Package', category: 'Special Package', price: '₱1,800', status: 'inactive', views: 89, bookings: 4 },
    { id: 5, name: 'Grilled Seafood Set', category: 'Food Package', price: '₱2,200', status: 'active', views: 445, bookings: 22 },
    { id: 6, name: 'VIP Seaside Dining', category: 'Experience', price: '₱6,500', status: 'draft', views: 0, bookings: 0 },
    { id: 7, name: 'Group Lunch Package', category: 'Group Dining', price: '₱3,500', status: 'active', views: 198, bookings: 11 },
    { id: 8, name: 'Sunset Dinner for 2', category: 'Romantic', price: '₱3,200', status: 'active', views: 312, bookings: 15 },
  ]
  const filtered = listings.filter(l =>
    (filter === 'all' || l.status === filter) &&
    l.name.toLowerCase().includes(search.toLowerCase())
  )
  return (
    <div className="page-transition space-y-6">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex items-center gap-2 flex-wrap">
          {['all', 'active', 'inactive', 'draft'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${filter === f ? 'text-white' : 'text-slate-500 hover:text-slate-300'}`}
              style={filter === f ? { background: 'rgba(249,115,22,0.2)', color: ORANGE } : { background: 'rgba(255,255,255,0.04)' }}
            >{f}</button>
          ))}
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input placeholder="Search listings..." value={search} onChange={e => setSearch(e.target.value)}
              className="pl-9 pr-3 py-2 text-sm w-44 rounded-xl"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', color: '#f1f5f9' }} />
          </div>
          <Btn size="sm" icon={<Plus size={14} />} onClick={() => onNav('add-listing')}>Add Listing</Btn>
        </div>
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
                {['Listing', 'Category', 'Price', 'Status', 'Views', 'Bookings', 'Actions'].map(h => (
                  <th key={h} className="text-left py-3 px-5 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(l => (
                <tr key={l.id} className="table-row" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <td className="py-3.5 px-5">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: 'rgba(249,115,22,0.1)' }}
                      ><Package size={16} className="text-orange-400" /></div>
                      <div className="text-sm font-semibold text-white">{l.name}</div>
                    </div>
                  </td>
                  <td className="py-3.5 px-5 text-sm text-slate-400">{l.category}</td>
                  <td className="py-3.5 px-5 text-sm font-semibold text-white">{l.price}</td>
                  <td className="py-3.5 px-5">
                    <Badge type={l.status === 'active' ? 'success' : l.status === 'inactive' ? 'gray' : 'warning'} label={l.status} />
                  </td>
                  <td className="py-3.5 px-5 text-sm text-slate-400">{l.views.toLocaleString()}</td>
                  <td className="py-3.5 px-5 text-sm text-slate-400">{l.bookings}</td>
                  <td className="py-3.5 px-5">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-blue-400 transition-colors" title="Edit" onClick={() => onNav('edit-listing')}>
                        <Edit3 size={14} />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-orange-400 transition-colors" title="View">
                        <Eye size={14} />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-red-400 transition-colors" title="Delete">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <List size={32} className="mx-auto mb-2 opacity-30" />
              <p className="text-sm">No listings found</p>
            </div>
          )}
        </div>
        <div className="flex items-center justify-between px-5 py-3.5" style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}>
          <span className="text-xs text-slate-500">Showing {filtered.length} of {listings.length} listings</span>
          <div className="flex gap-1">
            {[1, 2, 3].map(p => (
              <button key={p} className={`w-7 h-7 rounded-lg text-xs font-medium transition-all ${p === 1 ? 'text-white' : 'text-slate-500 hover:text-white'}`}
                style={p === 1 ? { background: 'rgba(249,115,22,0.2)', color: ORANGE } : { background: 'rgba(255,255,255,0.03)' }}>{p}</button>
            ))}
          </div>
        </div>
      </Card>
    </div>
  )
}

function AddListingPage({ onNav }: { onNav: (p: Page) => void }) {
  return (
    <div className="page-transition space-y-6 max-w-4xl">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 space-y-5">
          <h3 className="text-base font-bold text-white">Listing Details</h3>
          <Input label="Listing Title" placeholder="e.g., Seafood Platter for 2" required />
          <Select label="Category" options={[
            { label: 'Food Package', value: 'food' }, { label: 'Venue Rental', value: 'venue' },
            { label: 'Tour Package', value: 'tour' }, { label: 'Souvenir', value: 'souvenir' },
            { label: 'Experience', value: 'experience' }, { label: 'Accommodation', value: 'accom' },
          ]} />
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide block mb-1.5">
              Description <span className="text-orange-400">*</span>
            </label>
            <textarea rows={5} placeholder="Describe your listing in detail..."
              className="w-full px-3 py-2.5 text-sm resize-none"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Base Price (₱)" placeholder="0.00" type="number" required />
            <Select label="Price Type" options={[
              { label: 'Per Person', value: 'per_person' }, { label: 'Per Group', value: 'per_group' },
              { label: 'Fixed', value: 'fixed' },
            ]} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Min Persons" placeholder="1" type="number" />
            <Input label="Max Persons" placeholder="10" type="number" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide block mb-2">Inclusions</label>
            <div className="space-y-2">
              {['Free parking', 'Welcome drinks', 'Table service'].map((inc, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: ORANGE }} />
                  <span className="text-sm text-slate-300">{inc}</span>
                </div>
              ))}
              <input placeholder="+ Add inclusion..." className="w-full py-2 px-3 text-sm rounded-lg mt-2"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', color: '#f1f5f9' }} />
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <h3 className="text-sm font-bold text-white mb-4">Listing Status</h3>
            <Select label="Publish Status" options={[
              { label: 'Draft', value: 'draft' }, { label: 'Active', value: 'active' },
              { label: 'Inactive', value: 'inactive' },
            ]} />
            <div className="mt-4 p-3 rounded-xl" style={{ background: 'rgba(249,115,22,0.08)', border: '1px solid rgba(249,115,22,0.2)' }}>
              <div className="flex items-start gap-2 text-xs text-orange-300">
                <Info size={14} className="flex-shrink-0 mt-0.5" />
                Active listings are visible to tourists browsing Tubigon.
              </div>
            </div>
          </Card>

          <Card>
            <h3 className="text-sm font-bold text-white mb-4">Cover Image</h3>
            <div
              className="border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all hover:border-orange-400/50"
              style={{ borderColor: 'rgba(255,255,255,0.15)' }}
            >
              <Upload size={24} className="mx-auto text-slate-500 mb-2" />
              <p className="text-xs text-slate-400">Drop image here or click to upload</p>
              <p className="text-xs text-slate-600 mt-1">PNG, JPG up to 5MB</p>
            </div>
          </Card>

          <Card>
            <h3 className="text-sm font-bold text-white mb-3">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {['seafood', 'fresh', 'local', 'group'].map(t => (
                <span key={t} className="text-xs px-2.5 py-1 rounded-full font-medium" style={{ background: 'rgba(249,115,22,0.1)', color: ORANGE }}>
                  #{t} <X size={10} className="inline ml-1" />
                </span>
              ))}
            </div>
            <input placeholder="Add tag..." className="mt-2 w-full py-1.5 px-3 text-xs rounded-lg"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', color: '#f1f5f9' }} />
          </Card>

          <div className="flex gap-2">
            <Btn className="flex-1" size="sm" variant="ghost" onClick={() => onNav('listings')}>Cancel</Btn>
            <Btn className="flex-1" size="sm">Publish</Btn>
          </div>
        </div>
      </div>
    </div>
  )
}

function GalleryPage() {
  const [view, setView] = useState<'grid' | 'list'>('grid')
  const photos = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    title: `Photo ${i + 1}`,
    category: ['Interior', 'Food', 'Exterior', 'Team'][i % 4],
    size: `${(Math.random() * 3 + 0.5).toFixed(1)} MB`,
    featured: i < 3,
  }))
  const colors = ['#1e3a5f', '#3a1e5f', '#1e5f3a', '#5f3a1e', '#5f1e3a', '#3a5f1e', '#1e5f5f', '#5f5f1e']
  return (
    <div className="page-transition space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {['All', 'Interior', 'Food', 'Exterior', 'Team'].map(c => (
            <button key={c} className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
              style={{ background: c === 'All' ? 'rgba(249,115,22,0.2)' : 'rgba(255,255,255,0.04)', color: c === 'All' ? ORANGE : '#94a3b8' }}>
              {c}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setView('grid')} className={`p-2 rounded-lg transition-colors ${view === 'grid' ? 'text-orange-400' : 'text-slate-500'}`} style={{ background: view === 'grid' ? 'rgba(249,115,22,0.1)' : 'transparent' }}><Grid size={16} /></button>
          <button onClick={() => setView('list')} className={`p-2 rounded-lg transition-colors ${view === 'list' ? 'text-orange-400' : 'text-slate-500'}`} style={{ background: view === 'list' ? 'rgba(249,115,22,0.1)' : 'transparent' }}><List size={16} /></button>
          <Btn size="sm" icon={<Upload size={14} />}>Upload Photos</Btn>
        </div>
      </div>

      {/* Upload Drop Zone */}
      <div
        className="rounded-2xl border-2 border-dashed p-8 text-center transition-all hover:border-orange-400/50 cursor-pointer"
        style={{ borderColor: 'rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.02)' }}
      >
        <Upload size={32} className="mx-auto text-slate-600 mb-3" />
        <p className="text-sm font-medium text-slate-400">Drag & drop photos here</p>
        <p className="text-xs text-slate-600 mt-1">PNG, JPG, WebP — max 5MB each</p>
        <Btn size="sm" className="mt-3" variant="ghost">Browse Files</Btn>
      </div>

      {view === 'grid' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {photos.map((p, i) => (
            <div
              key={p.id}
              className="rounded-xl overflow-hidden relative group cursor-pointer animate-fade-in-up"
              style={{ animationDelay: `${i * 30}ms`, border: '1px solid rgba(255,255,255,0.07)' }}
            >
              <div className="aspect-square flex items-center justify-center" style={{ background: colors[i % colors.length] }}>
                <Camera size={28} style={{ color: 'rgba(255,255,255,0.2)' }} />
              </div>
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                <div className="flex gap-2">
                  <button className="p-2 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-colors"><Eye size={14} /></button>
                  <button className="p-2 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-colors"><Edit3 size={14} /></button>
                  <button className="p-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
              {p.featured && (
                <div className="absolute top-2 left-2">
                  <span className="badge badge-orange">Featured</span>
                </div>
              )}
              <div className="p-2.5" style={{ background: '#0e1628' }}>
                <div className="text-xs font-semibold text-white truncate">{p.title}</div>
                <div className="flex justify-between mt-0.5">
                  <span className="text-xs text-slate-500">{p.category}</span>
                  <span className="text-xs text-slate-600">{p.size}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <Card className="p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
                  {['Photo', 'Category', 'Size', 'Status', 'Actions'].map(h => (
                    <th key={h} className="text-left py-3 px-5 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {photos.map((p, i) => (
                  <tr key={p.id} className="table-row" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <td className="py-3 px-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: colors[i % colors.length] }}>
                          <Camera size={14} style={{ color: 'rgba(255,255,255,0.3)' }} />
                        </div>
                        <span className="text-sm font-medium text-white">{p.title}</span>
                      </div>
                    </td>
                    <td className="py-3 px-5 text-sm text-slate-400">{p.category}</td>
                    <td className="py-3 px-5 text-sm text-slate-400">{p.size}</td>
                    <td className="py-3 px-5"><Badge type={p.featured ? 'orange' : 'gray'} label={p.featured ? 'Featured' : 'Normal'} /></td>
                    <td className="py-3 px-5">
                      <div className="flex items-center gap-1">
                        <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-blue-400 transition-colors"><Eye size={14} /></button>
                        <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-red-400 transition-colors"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  )
}

function ReservationsPage() {
  const [tab, setTab] = useState('all')
  const reservations = [
    { id: 'RES-2408-001', name: 'Maria Santos', service: 'Seafood Platter for 4', date: 'Aug 3, 2026', time: '12:00 PM', persons: 4, amount: '₱2,800', status: 'confirmed', phone: '+63 917 123 4567' },
    { id: 'RES-2408-002', name: 'Jose Reyes', service: 'Private Dining Room', date: 'Aug 4, 2026', time: '7:00 PM', persons: 6, amount: '₱4,800', status: 'pending', phone: '+63 905 234 5678' },
    { id: 'RES-2408-003', name: 'Ana Lim', service: 'Bangus Festival Package', date: 'Aug 5, 2026', time: '12:30 PM', persons: 2, amount: '₱1,800', status: 'confirmed', phone: '+63 919 345 6789' },
    { id: 'RES-2408-004', name: 'Carlo Mendoza', service: 'Group Lunch Package', date: 'Aug 6, 2026', time: '11:00 AM', persons: 8, amount: '₱3,500', status: 'cancelled', phone: '+63 912 456 7890' },
    { id: 'RES-2408-005', name: 'Rosa Garcia', service: 'Sunset Dinner for 2', date: 'Aug 7, 2026', time: '6:00 PM', persons: 2, amount: '₱3,200', status: 'pending', phone: '+63 998 567 8901' },
    { id: 'RES-2408-006', name: 'Ben Torres', service: 'Seafood Platter for 2', date: 'Aug 8, 2026', time: '1:00 PM', persons: 2, amount: '₱1,600', status: 'completed', phone: '+63 906 678 9012' },
  ]
  const tabs = [
    { id: 'all', label: 'All', count: reservations.length },
    { id: 'pending', label: 'Pending', count: reservations.filter(r => r.status === 'pending').length },
    { id: 'confirmed', label: 'Confirmed', count: reservations.filter(r => r.status === 'confirmed').length },
    { id: 'completed', label: 'Completed', count: reservations.filter(r => r.status === 'completed').length },
    { id: 'cancelled', label: 'Cancelled', count: reservations.filter(r => r.status === 'cancelled').length },
  ]
  const filtered = tab === 'all' ? reservations : reservations.filter(r => r.status === tab)
  return (
    <div className="page-transition space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Today's Bookings" value="3" icon={<Calendar size={18} />} trend="up" trendValue="+2" delay={0} />
        <StatCard title="Pending Review" value="2" icon={<Clock3 size={18} />} color="#eab308" delay={60} />
        <StatCard title="This Month" value="58" icon={<CheckCircle size={18} />} color="#22c55e" trend="up" trendValue="+8" delay={120} />
        <StatCard title="Revenue" value="₱54,400" icon={<DollarSign size={18} />} trend="up" trendValue="+12%" delay={180} />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all"
            style={tab === t.id ? { background: '#0e1628', color: ORANGE, boxShadow: '0 2px 8px rgba(0,0,0,0.3)' } : { color: '#64748b' }}>
            {t.label}
            <span className="px-1.5 py-0.5 rounded-full text-xs" style={{ background: tab === t.id ? 'rgba(249,115,22,0.2)' : 'rgba(255,255,255,0.06)', color: tab === t.id ? ORANGE : '#64748b' }}>
              {t.count}
            </span>
          </button>
        ))}
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
          <span className="text-sm font-semibold text-white">{filtered.length} Reservations</span>
          <div className="flex gap-2">
            <Btn size="sm" variant="ghost" icon={<Filter size={14} />}>Filter</Btn>
            <Btn size="sm" variant="ghost" icon={<Download size={14} />}>Export</Btn>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
                {['Booking ID', 'Customer', 'Service', 'Date & Time', 'Persons', 'Amount', 'Status', 'Actions'].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => (
                <tr key={r.id} className="table-row" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <td className="py-3.5 px-4 text-xs font-mono text-slate-400">{r.id}</td>
                  <td className="py-3.5 px-4">
                    <div className="text-sm font-semibold text-white">{r.name}</div>
                    <div className="text-xs text-slate-500">{r.phone}</div>
                  </td>
                  <td className="py-3.5 px-4 text-sm text-slate-300">{r.service}</td>
                  <td className="py-3.5 px-4">
                    <div className="text-sm text-white">{r.date}</div>
                    <div className="text-xs text-slate-500">{r.time}</div>
                  </td>
                  <td className="py-3.5 px-4 text-sm text-slate-300">{r.persons} pax</td>
                  <td className="py-3.5 px-4 text-sm font-semibold text-white">{r.amount}</td>
                  <td className="py-3.5 px-4">
                    <Badge type={r.status === 'confirmed' ? 'success' : r.status === 'pending' ? 'warning' : r.status === 'completed' ? 'info' : 'error'} label={r.status} />
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex gap-1">
                      {r.status === 'pending' && (
                        <>
                          <button className="p-1.5 rounded-lg bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors" title="Confirm"><CheckCircle size={14} /></button>
                          <button className="p-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors" title="Decline"><XCircle size={14} /></button>
                        </>
                      )}
                      <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-slate-300 transition-colors" title="More"><MoreVertical size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}

function ReviewsPage() {
  const reviews = [
    { name: 'Maria Santos', rating: 5, date: 'Aug 1, 2026', comment: "Best seafood in Tubigon! The bangus was fresh and cooked perfectly. Will definitely come back for more. Great service and ambiance too.", replied: true },
    { name: 'Jose Reyes', rating: 4, date: 'Jul 28, 2026', comment: "Great food and reasonable prices. Service was a bit slow during peak hours but overall a good experience. The grilled squid was amazing!", replied: false },
    { name: 'Ana Lim', rating: 5, date: 'Jul 25, 2026', comment: "Perfect place for family gatherings. We celebrated my birthday here and the staff were very accommodating. Highly recommend the seafood platter!", replied: true },
    { name: 'Carlo Mendoza', rating: 3, date: 'Jul 22, 2026', comment: "Food was okay but the waiting time was too long. Hope they can improve their service during busy periods.", replied: false },
    { name: 'Rosa Garcia', rating: 5, date: 'Jul 19, 2026', comment: "Excellent! The freshest seafood I've had in Bohol. The owner was very friendly and helped us choose the best dishes.", replied: true },
  ]
  return (
    <div className="page-transition space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <Card className="lg:col-span-1">
          <div className="text-center">
            <div className="text-5xl font-bold text-white mb-2" style={{ fontFamily: "'DM Sans', sans-serif" }}>4.7</div>
            <div className="flex justify-center gap-0.5 mb-2">
              {[1,2,3,4,5].map(s => <Star key={s} size={18} fill={s <= 4 ? '#eab308' : 'none'} className="text-yellow-400" />)}
            </div>
            <div className="text-sm text-slate-400">Based on 89 reviews</div>
            <div className="mt-4 space-y-2">
              {[
                { stars: 5, pct: 51 }, { stars: 4, pct: 31 },
                { stars: 3, pct: 11 }, { stars: 2, pct: 4 }, { stars: 1, pct: 3 },
              ].map(r => (
                <div key={r.stars} className="flex items-center gap-2 text-xs">
                  <span className="text-slate-500 w-8">{r.stars}★</span>
                  <div className="flex-1 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <div className="h-full rounded-full" style={{ width: `${r.pct}%`, background: r.stars >= 4 ? '#22c55e' : r.stars === 3 ? '#eab308' : '#ef4444' }} />
                  </div>
                  <span className="text-slate-400 w-8 text-right">{r.pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        <div className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between">
            <Select label="" options={[{ label: 'All Reviews', value: 'all' }, { label: '5 Stars', value: '5' }, { label: 'Unanswered', value: 'unanswered' }]} />
            <Btn size="sm" variant="ghost" icon={<Download size={14} />}>Export</Btn>
          </div>
          {reviews.map((r, i) => (
            <Card key={i} className="animate-fade-in-up" style={{ animationDelay: `${i * 60}ms` }}>
              <div className="flex items-start gap-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold text-white flex-shrink-0"
                  style={{ background: `hsl(${i * 70 + 180}, 60%, 40%)` }}
                >{r.name[0]}</div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-semibold text-white">{r.name}</span>
                    <div className="flex gap-0.5">{[1,2,3,4,5].map(s => <Star key={s} size={12} fill={s <= r.rating ? '#eab308' : 'none'} className="text-yellow-400" />)}</div>
                    <span className="text-xs text-slate-500 ml-auto">{r.date}</span>
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed">{r.comment}</p>
                  {r.replied && (
                    <div className="mt-3 p-3 rounded-xl" style={{ background: 'rgba(249,115,22,0.05)', border: '1px solid rgba(249,115,22,0.15)' }}>
                      <div className="text-xs font-semibold text-orange-400 mb-1 flex items-center gap-1">
                        <Store size={12} /> Your Reply
                      </div>
                      <p className="text-xs text-slate-400">Thank you for your kind words! We're glad you enjoyed your experience. We look forward to serving you again!</p>
                    </div>
                  )}
                  {!r.replied && (
                    <button className="mt-3 flex items-center gap-1.5 text-xs text-orange-400 hover:text-orange-300 transition-colors">
                      <MessageSquare size={12} /> Write a reply
                    </button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

function AnalyticsPage() {
  return (
    <div className="page-transition space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Revenue" value="₱143,800" icon={<DollarSign size={18} />} trend="up" trendValue="+12.4%" delay={0} />
        <StatCard title="Total Bookings" value="234" icon={<Calendar size={18} />} trend="up" trendValue="+18.2%" color="#3b82f6" delay={60} />
        <StatCard title="Profile Views" value="4,856" icon={<Eye size={18} />} trend="down" trendValue="-3.1%" color="#8b5cf6" delay={120} />
        <StatCard title="Conversion Rate" value="4.8%" icon={<Target size={18} />} trend="up" trendValue="+0.6%" color="#22c55e" delay={180} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <SectionHeader title="Revenue Trend" subtitle="Monthly revenue (₱)" />
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="ag1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={ORANGE} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={ORANGE} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="month" stroke="#475569" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis stroke="#475569" tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip contentStyle={{ background: '#0e1628', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }} />
              <Area type="monotone" dataKey="revenue" stroke={ORANGE} fill="url(#ag1)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Weekly Traffic" subtitle="Profile views vs clicks" />
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={trafficData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="day" stroke="#475569" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis stroke="#475569" tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip contentStyle={{ background: '#0e1628', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }} />
              <Legend />
              <Bar dataKey="views" fill="#3b82f6" radius={[4,4,0,0]} />
              <Bar dataKey="clicks" fill={ORANGE} radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <SectionHeader title="Top Listings" subtitle="By booking count" />
          <div className="space-y-3">
            {[
              { name: 'Seafood Platter for 4', bookings: 32, revenue: '₱89,600', pct: 100 },
              { name: 'Grilled Seafood Set', bookings: 22, revenue: '₱48,400', pct: 69 },
              { name: 'Sunset Dinner for 2', bookings: 15, revenue: '₱48,000', pct: 47 },
              { name: 'Group Lunch Package', bookings: 11, revenue: '₱38,500', pct: 34 },
              { name: 'Private Dining Room', bookings: 9, revenue: '₱43,200', pct: 28 },
            ].map((item, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-slate-300 font-medium">{item.name}</span>
                  <span className="text-slate-500">{item.bookings} bookings</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${item.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionHeader title="Booking Sources" subtitle="Where customers found you" />
          <ResponsiveContainer width="100%" height={180}>
            <RechartsPie>
              <Pie data={[
                { name: 'Tubigon App', value: 45, color: ORANGE },
                { name: 'Facebook', value: 28, color: '#3b82f6' },
                { name: 'Walk-in', value: 15, color: '#22c55e' },
                { name: 'Referral', value: 12, color: '#8b5cf6' },
              ]} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={3} dataKey="value">
                {[ORANGE, '#3b82f6', '#22c55e', '#8b5cf6'].map((c, i) => <Cell key={i} fill={c} />)}
              </Pie>
              <Tooltip contentStyle={{ background: '#0e1628', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }} />
            </RechartsPie>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {[{ label: 'Tubigon App', color: ORANGE, pct: '45%' }, { label: 'Facebook', color: '#3b82f6', pct: '28%' }, { label: 'Walk-in', color: '#22c55e', pct: '15%' }, { label: 'Referral', color: '#8b5cf6', pct: '12%' }].map(s => (
              <div key={s.label} className="flex items-center gap-1.5 text-xs">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: s.color }} />
                <span className="text-slate-400">{s.label}</span>
                <span className="ml-auto text-slate-300 font-medium">{s.pct}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionHeader title="Customer Demographics" subtitle="Age & origin insights" />
          <div className="space-y-4">
            <div>
              <div className="text-xs text-slate-500 mb-2">Age Groups</div>
              {[{ label: '18–25', pct: 22 }, { label: '26–35', pct: 38 }, { label: '36–50', pct: 28 }, { label: '51+', pct: 12 }].map(g => (
                <div key={g.label} className="flex items-center gap-2 text-xs mb-2">
                  <span className="text-slate-400 w-12">{g.label}</span>
                  <div className="flex-1 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <div className="h-full rounded-full" style={{ width: `${g.pct * 2.5}%`, background: ORANGE }} />
                  </div>
                  <span className="text-slate-300 font-medium w-8 text-right">{g.pct}%</span>
                </div>
              ))}
            </div>
            <div style={{ borderTop: '1px solid rgba(255,255,255,0.07)', paddingTop: 12 }}>
              <div className="text-xs text-slate-500 mb-2">Top Origins</div>
              {[{ label: 'Cebu City', count: 42 }, { label: 'Tagbilaran', count: 31 }, { label: 'Manila', count: 18 }, { label: 'Tubigon Local', count: 56 }].map(o => (
                <div key={o.label} className="flex justify-between text-xs py-1">
                  <span className="text-slate-400">{o.label}</span>
                  <span className="text-slate-300 font-medium">{o.count} visitors</span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

function PromotionsPage() {
  const promos = [
    { name: 'Bangus Festival Discount', code: 'BANGUS2026', discount: '20%', type: 'Percentage', uses: 34, maxUses: 100, expiry: 'Aug 15, 2026', status: 'active' },
    { name: 'Weekend Special', code: 'WKND50', discount: '₱50 off', type: 'Fixed', uses: 12, maxUses: 50, expiry: 'Aug 31, 2026', status: 'active' },
    { name: 'Group Discount', code: 'GROUP15', discount: '15%', type: 'Percentage', uses: 8, maxUses: 30, expiry: 'Sep 30, 2026', status: 'active' },
    { name: 'Summer Sale', code: 'SUMMER25', discount: '25%', type: 'Percentage', uses: 50, maxUses: 50, expiry: 'Jul 31, 2026', status: 'expired' },
  ]
  return (
    <div className="page-transition space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Active Promos" value="3" icon={<Tag size={18} />} delay={0} />
        <StatCard title="Total Redemptions" value="104" icon={<Zap size={18} />} color="#8b5cf6" trend="up" trendValue="+22" delay={60} />
        <StatCard title="Discount Given" value="₱8,240" icon={<Percent size={18} />} color="#ef4444" delay={120} />
        <StatCard title="Revenue Impact" value="+18%" icon={<TrendingUp size={18} />} color="#22c55e" delay={180} />
      </div>

      <div className="flex justify-between items-center">
        <div />
        <Btn icon={<Plus size={14} />}>Create Promotion</Btn>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {promos.map((p, i) => (
          <Card key={i} className="animate-fade-in-up" style={{ animationDelay: `${i * 60}ms` }}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="text-base font-bold text-white mb-1">{p.name}</div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs px-2 py-1 rounded-lg" style={{ background: 'rgba(249,115,22,0.1)', color: ORANGE, letterSpacing: '0.05em' }}>
                    {p.code}
                  </span>
                  <button className="text-slate-600 hover:text-slate-400 transition-colors"><Copy size={12} /></button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge type={p.status === 'active' ? 'success' : 'error'} label={p.status} />
                <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-slate-300 transition-colors"><MoreVertical size={14} /></button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-4 text-center">
              <div className="rounded-xl py-2 px-3" style={{ background: 'rgba(255,255,255,0.04)' }}>
                <div className="text-lg font-bold text-orange-400" style={{ fontFamily: "'DM Sans', sans-serif" }}>{p.discount}</div>
                <div className="text-xs text-slate-500">{p.type}</div>
              </div>
              <div className="rounded-xl py-2 px-3" style={{ background: 'rgba(255,255,255,0.04)' }}>
                <div className="text-lg font-bold text-white" style={{ fontFamily: "'DM Sans', sans-serif" }}>{p.uses}</div>
                <div className="text-xs text-slate-500">Used</div>
              </div>
              <div className="rounded-xl py-2 px-3" style={{ background: 'rgba(255,255,255,0.04)' }}>
                <div className="text-lg font-bold text-white" style={{ fontFamily: "'DM Sans', sans-serif" }}>{p.maxUses}</div>
                <div className="text-xs text-slate-500">Max Uses</div>
              </div>
            </div>

            <div className="mb-3">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-500">Usage</span>
                <span className="text-slate-400">{Math.round(p.uses / p.maxUses * 100)}%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${p.uses / p.maxUses * 100}%`, background: p.status === 'expired' ? '#64748b' : undefined }} />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Expires: <span className="text-slate-300">{p.expiry}</span></span>
              <div className="flex gap-1">
                <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-blue-400 transition-colors"><Edit3 size={12} /></button>
                <button className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-red-400 transition-colors"><Trash2 size={12} /></button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}

function NotificationsPage() {
  const notifs = [
    { type: 'booking', icon: <Calendar size={16} />, color: '#3b82f6', title: 'New Reservation', desc: 'Maria Santos booked Seafood Platter for 4 on Aug 3', time: '2 min ago', unread: true },
    { type: 'review', icon: <Star size={16} />, color: '#eab308', title: 'New Review', desc: 'Jose Reyes left a 4-star review on your listing', time: '1 hr ago', unread: true },
    { type: 'alert', icon: <AlertCircle size={16} />, color: ORANGE, title: 'Permit Expiry Reminder', desc: "Your Mayor's Permit expires in 30 days. Please renew.", time: '3 hrs ago', unread: true },
    { type: 'promo', icon: <Tag size={16} />, color: '#8b5cf6', title: 'Promotion Milestone', desc: 'BANGUS2026 promo has been redeemed 30 times!', time: '5 hrs ago', unread: false },
    { type: 'booking', icon: <CheckCircle size={16} />, color: '#22c55e', title: 'Booking Confirmed', desc: 'Ana Lim confirmed her reservation for Aug 5', time: '1 day ago', unread: false },
    { type: 'system', icon: <Zap size={16} />, color: '#06b6d4', title: 'Analytics Report Ready', desc: 'Your July 2026 business report is ready to download', time: '2 days ago', unread: false },
    { type: 'review', icon: <MessageSquare size={16} />, color: '#f43f5e', title: 'Review Needs Response', desc: 'Carlo Mendoza left a 3-star review 2 days ago without a reply', time: '2 days ago', unread: false },
  ]
  return (
    <div className="page-transition space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {['All', 'Unread', 'Bookings', 'Reviews', 'System'].map(f => (
            <button key={f} className="px-3 py-1.5 rounded-lg text-xs font-semibold"
              style={{ background: f === 'All' ? 'rgba(249,115,22,0.15)' : 'rgba(255,255,255,0.04)', color: f === 'All' ? ORANGE : '#64748b' }}>{f}</button>
          ))}
        </div>
        <Btn size="sm" variant="ghost">Mark all read</Btn>
      </div>
      <div className="space-y-2">
        {notifs.map((n, i) => (
          <div
            key={i}
            className="glass-card rounded-xl p-4 flex items-start gap-3 cursor-pointer transition-all hover:border-white/10 animate-fade-in-up"
            style={{ animationDelay: `${i * 40}ms`, border: `1px solid ${n.unread ? 'rgba(249,115,22,0.15)' : 'rgba(255,255,255,0.06)'}` }}
          >
            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${n.color}1a`, color: n.color }}>
              {n.icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-white">{n.title}</span>
                {n.unread && <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: ORANGE }} />}
              </div>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{n.desc}</p>
            </div>
            <span className="text-xs text-slate-600 flex-shrink-0">{n.time}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function ReportsPage() {
  return (
    <div className="page-transition space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <SectionHeader title="Generate Report" subtitle="Create custom business reports" />
          <div className="grid grid-cols-2 gap-4 mb-5">
            <Select label="Report Type" options={[
              { label: 'Revenue Report', value: 'revenue' }, { label: 'Booking Report', value: 'bookings' },
              { label: 'Customer Report', value: 'customers' }, { label: 'Listing Performance', value: 'listings' },
            ]} />
            <Select label="Period" options={[
              { label: 'This Month', value: 'month' }, { label: 'Last 3 Months', value: '3months' },
              { label: 'This Year', value: 'year' }, { label: 'Custom Range', value: 'custom' },
            ]} />
            <Input label="Date From" type="date" value="2026-07-01" />
            <Input label="Date To" type="date" value="2026-08-03" />
          </div>
          <div className="flex gap-3">
            <Btn icon={<FileText size={14} />}>Generate PDF</Btn>
            <Btn variant="ghost" icon={<Download size={14} />}>Export CSV</Btn>
            <Btn variant="ghost" icon={<Download size={14} />}>Export Excel</Btn>
          </div>
        </Card>

        <Card>
          <SectionHeader title="Quick Stats" subtitle="Current period" />
          <div className="space-y-4">
            {[
              { label: 'Gross Revenue', value: '₱143,800', color: ORANGE },
              { label: 'Net Revenue', value: '₱128,420', color: '#22c55e' },
              { label: 'Total Bookings', value: '234', color: '#3b82f6' },
              { label: 'Cancellations', value: '12 (5.1%)', color: '#ef4444' },
              { label: 'Avg Booking Value', value: '₱2,477', color: '#8b5cf6' },
            ].map(s => (
              <div key={s.label} className="flex items-center justify-between p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <span className="text-sm text-slate-400">{s.label}</span>
                <span className="text-sm font-bold" style={{ color: s.color }}>{s.value}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <SectionHeader title="Recent Reports" action={<Btn size="sm" variant="ghost" icon={<RefreshCw size={14} />}>Refresh</Btn>} />
        <div className="space-y-0">
          {[
            { name: 'July 2026 Revenue Report', type: 'Revenue', date: 'Aug 1, 2026', size: '1.2 MB', format: 'PDF' },
            { name: 'Q2 2026 Bookings Summary', type: 'Bookings', date: 'Jul 1, 2026', size: '2.8 MB', format: 'Excel' },
            { name: 'June 2026 Customer Analytics', type: 'Customers', date: 'Jul 1, 2026', size: '0.9 MB', format: 'CSV' },
            { name: 'H1 2026 Business Performance', type: 'Performance', date: 'Jun 30, 2026', size: '4.1 MB', format: 'PDF' },
          ].map((r, i) => (
            <div key={i} className="table-row flex items-center gap-4 py-3.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: 'rgba(249,115,22,0.1)' }}
              ><FileText size={18} className="text-orange-400" /></div>
              <div className="flex-1">
                <div className="text-sm font-semibold text-white">{r.name}</div>
                <div className="text-xs text-slate-500">{r.type} · {r.date} · {r.size}</div>
              </div>
              <span className="badge badge-gray">{r.format}</span>
              <Btn size="sm" variant="ghost" icon={<Download size={12} />}>Download</Btn>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}

function CalendarPage() {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
  const dates = Array.from({ length: 35 }, (_, i) => {
    const d = i - 3
    return { day: d + 1, inMonth: d >= 0 && d < 31 }
  })
  const bookingDays = [3, 4, 5, 7, 10, 12, 14, 17, 19, 21, 24, 26, 28]
  const blockedDays = [8, 15, 22, 29]
  return (
    <div className="page-transition space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-base font-bold text-white">August 2026</h3>
            <div className="flex gap-2">
              <button className="p-2 rounded-lg hover:bg-white/5 text-slate-400 transition-colors"><ChevronLeft size={16} /></button>
              <button className="px-3 py-1.5 rounded-lg text-sm text-orange-400 font-medium" style={{ background: 'rgba(249,115,22,0.1)' }}>Today</button>
              <button className="p-2 rounded-lg hover:bg-white/5 text-slate-400 transition-colors"><ChevronRight size={16} /></button>
            </div>
          </div>
          <div className="grid grid-cols-7 gap-1 mb-2">
            {days.map(d => <div key={d} className="text-center text-xs font-semibold text-slate-600 py-2">{d}</div>)}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {dates.map((d, i) => {
              const isBooked = d.inMonth && bookingDays.includes(d.day)
              const isBlocked = d.inMonth && blockedDays.includes(d.day)
              const isToday = d.day === 3 && d.inMonth
              return (
                <div
                  key={i}
                  className={`aspect-square rounded-xl flex flex-col items-center justify-center text-sm cursor-pointer transition-all ${!d.inMonth ? 'opacity-20' : 'hover:bg-white/5'}`}
                  style={
                    isToday ? { background: ORANGE, color: 'white', fontWeight: 700 } :
                    isBooked ? { background: 'rgba(59,130,246,0.15)', color: '#93c5fd' } :
                    isBlocked ? { background: 'rgba(239,68,68,0.1)', color: '#fca5a5' } :
                    {}
                  }
                >
                  <span>{d.day > 0 ? d.day : ''}</span>
                  {isBooked && <span className="w-1 h-1 rounded-full bg-blue-400 mt-0.5" />}
                  {isBlocked && <span className="w-1 h-1 rounded-full bg-red-400 mt-0.5" />}
                </div>
              )
            })}
          </div>
          <div className="flex items-center gap-5 mt-4 pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}>
            {[
              { color: ORANGE, label: 'Today' },
              { color: '#93c5fd', label: 'Has Bookings' },
              { color: '#fca5a5', label: 'Blocked' },
            ].map(l => (
              <div key={l.label} className="flex items-center gap-2 text-xs text-slate-400">
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: l.color }} />
                {l.label}
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <h3 className="text-sm font-bold text-white mb-4">Availability Settings</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between py-2">
                <span className="text-sm text-slate-300">Accept Bookings</span>
                <div className="w-10 h-5 rounded-full relative cursor-pointer" style={{ background: ORANGE }}>
                  <div className="w-4 h-4 rounded-full bg-white absolute top-0.5 right-0.5 shadow" />
                </div>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-sm text-slate-300">Instant Booking</span>
                <div className="w-10 h-5 rounded-full relative cursor-pointer" style={{ background: 'rgba(255,255,255,0.1)' }}>
                  <div className="w-4 h-4 rounded-full bg-slate-400 absolute top-0.5 left-0.5 shadow" />
                </div>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-sm text-slate-300">Buffer Time</span>
                <Select label="" options={[{ label: '30 min', value: '30' }, { label: '1 hour', value: '60' }]} />
              </div>
            </div>
          </Card>

          <Card>
            <h3 className="text-sm font-bold text-white mb-4">Upcoming Bookings</h3>
            <div className="space-y-3">
              {[
                { date: 'Aug 3', name: 'Maria Santos', service: 'Platter for 4', time: '12:00 PM' },
                { date: 'Aug 4', name: 'Jose Reyes', service: 'Private Dining', time: '7:00 PM' },
                { date: 'Aug 5', name: 'Ana Lim', service: 'Festival Package', time: '12:30 PM' },
              ].map((b, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex flex-col items-center justify-center flex-shrink-0" style={{ background: 'rgba(249,115,22,0.1)' }}>
                    <span className="text-xs font-bold text-orange-400 leading-none">{b.date.split(' ')[1]}</span>
                    <span className="text-xs text-slate-500 leading-none">{b.date.split(' ')[0]}</span>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">{b.name}</div>
                    <div className="text-xs text-slate-500">{b.service} · {b.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="text-sm font-bold text-white mb-3">Block Dates</h3>
            <Input label="Block Date" type="date" />
            <Btn className="w-full mt-3" size="sm" variant="ghost">Block Selected Date</Btn>
          </Card>
        </div>
      </div>
    </div>
  )
}

function SettingsPage() {
  return (
    <div className="page-transition space-y-6 max-w-3xl">
      {[
        {
          title: 'Account Security',
          icon: <Shield size={18} />,
          items: [
            { label: 'Change Password', desc: 'Last changed 30 days ago', action: <Btn size="sm" variant="ghost" icon={<Key size={12} />}>Update</Btn> },
            { label: 'Two-Factor Authentication', desc: 'Add an extra layer of security', action: <div className="w-10 h-5 rounded-full relative cursor-pointer" style={{ background: ORANGE }}><div className="w-4 h-4 rounded-full bg-white absolute top-0.5 right-0.5 shadow" /></div> },
            { label: 'Active Sessions', desc: '2 active sessions', action: <Btn size="sm" variant="ghost">Manage</Btn> },
          ],
        },
        {
          title: 'Notifications',
          icon: <Bell size={18} />,
          items: [
            { label: 'New Reservations', desc: 'Receive alerts for new bookings', action: <div className="w-10 h-5 rounded-full cursor-pointer" style={{ background: ORANGE, position: 'relative' }}><div className="w-4 h-4 rounded-full bg-white absolute top-0.5 right-0.5 shadow" /></div> },
            { label: 'Review Notifications', desc: 'Get notified for new reviews', action: <div className="w-10 h-5 rounded-full cursor-pointer" style={{ background: ORANGE, position: 'relative' }}><div className="w-4 h-4 rounded-full bg-white absolute top-0.5 right-0.5 shadow" /></div> },
            { label: 'Promotional Alerts', desc: 'Updates on promo performance', action: <div className="w-10 h-5 rounded-full cursor-pointer" style={{ background: 'rgba(255,255,255,0.1)', position: 'relative' }}><div className="w-4 h-4 rounded-full bg-slate-400 absolute top-0.5 left-0.5 shadow" /></div> },
          ],
        },
        {
          title: 'Billing & Subscription',
          icon: <CreditCard size={18} />,
          items: [
            { label: 'Current Plan', desc: 'MSME Basic Plan — Free', action: <Btn size="sm" icon={<Zap size={12} />}>Upgrade</Btn> },
            { label: 'Payment Method', desc: 'No payment method added', action: <Btn size="sm" variant="ghost">Add Card</Btn> },
          ],
        },
        {
          title: 'Danger Zone',
          icon: <AlertCircle size={18} />,
          items: [
            { label: 'Deactivate Business Listing', desc: 'Temporarily hide your business', action: <Btn size="sm" variant="danger">Deactivate</Btn> },
            { label: 'Delete Account', desc: 'Permanently remove your account and data', action: <Btn size="sm" variant="danger" icon={<Trash2 size={12} />}>Delete</Btn> },
          ],
        },
      ].map(section => (
        <Card key={section.title}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-orange-400">{section.icon}</span>
            <h3 className="text-base font-bold text-white">{section.title}</h3>
          </div>
          <div className="space-y-0">
            {section.items.map((item, i) => (
              <div key={i} className="flex items-center justify-between py-4" style={{ borderBottom: i < section.items.length - 1 ? '1px solid rgba(255,255,255,0.06)' : undefined }}>
                <div>
                  <div className="text-sm font-semibold text-white">{item.label}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{item.desc}</div>
                </div>
                {item.action}
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  )
}

function HelpPage() {
  const faqs = [
    { q: 'How do I verify my business?', a: 'Upload your DTI Registration, Barangay Clearance, and Mayor\'s Permit in the Business Profile section under Verification Documents.' },
    { q: 'How do I respond to customer reviews?', a: 'Go to Customer Reviews, find the review you want to respond to, and click "Write a reply" below the review.' },
    { q: 'Can I set custom pricing per day?', a: 'Yes! Use the Availability Calendar to set different pricing and availability for specific dates and seasons.' },
    { q: 'How are reservations handled?', a: 'Customers book through the Tubigon STIMS app. You\'ll receive a notification and can confirm or decline from the Reservations page.' },
    { q: 'How do I create a promotion?', a: 'Navigate to Promotions & Discounts, click "Create Promotion", and fill in the promo details including the discount type and validity period.' },
  ]
  const [open, setOpen] = useState<number | null>(null)
  return (
    <div className="page-transition space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-4">
          {[
            { icon: <MessageSquare size={20} />, title: 'Live Chat', desc: 'Chat with a support agent', color: '#3b82f6', cta: 'Start Chat' },
            { icon: <Mail size={20} />, title: 'Email Support', desc: 'support@tubigonstims.gov.ph', color: ORANGE, cta: 'Send Email' },
            { icon: <Phone size={20} />, title: 'Phone Support', desc: '+63 38 500 9000', color: '#22c55e', cta: 'Call Now' },
          ].map(c => (
            <Card key={c.title}>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${c.color}1a`, color: c.color }}>
                  {c.icon}
                </div>
                <div>
                  <div className="text-sm font-bold text-white">{c.title}</div>
                  <div className="text-xs text-slate-500">{c.desc}</div>
                </div>
              </div>
              <Btn size="sm" variant="ghost" className="w-full justify-center">{c.cta}</Btn>
            </Card>
          ))}
        </div>

        <div className="lg:col-span-2 space-y-4">
          <Card>
            <SectionHeader title="Frequently Asked Questions" />
            <div className="space-y-2">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-xl overflow-hidden"
                  style={{ border: '1px solid rgba(255,255,255,0.07)' }}
                >
                  <button
                    onClick={() => setOpen(open === i ? null : i)}
                    className="w-full flex items-center justify-between p-4 text-left transition-colors hover:bg-white/2"
                  >
                    <span className="text-sm font-semibold text-white">{faq.q}</span>
                    <ChevronDown size={16} className={`text-slate-500 flex-shrink-0 ml-2 transition-transform ${open === i ? 'rotate-180' : ''}`} />
                  </button>
                  {open === i && (
                    <div className="px-4 pb-4 text-sm text-slate-400 leading-relaxed animate-fade-in" style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}>
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <SectionHeader title="Video Tutorials" />
            <div className="grid grid-cols-2 gap-3">
              {[
                'Getting Started with MSME Dashboard',
                'Managing Your Reservations',
                'Creating Effective Promotions',
                'Boosting Your Business Profile',
              ].map((title, i) => (
                <div key={i} className="rounded-xl overflow-hidden cursor-pointer group" style={{ border: '1px solid rgba(255,255,255,0.07)' }}>
                  <div className="h-24 flex items-center justify-center group-hover:bg-white/5 transition-colors" style={{ background: `hsl(${i * 60 + 200}, 30%, 15%)` }}>
                    <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'rgba(249,115,22,0.2)' }}>
                      <Activity size={20} className="text-orange-400" />
                    </div>
                  </div>
                  <div className="p-3">
                    <div className="text-xs font-medium text-slate-300 leading-snug">{title}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState<Page>('dashboard')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navigate = (p: Page) => {
    setPage(p)
    setMobileMenuOpen(false)
  }

  const renderPage = () => {
    switch (page) {
      case 'dashboard': return <DashboardPage onNav={navigate} />
      case 'profile': return <BusinessProfilePage />
      case 'listings': return <ListingsPage onNav={navigate} />
      case 'add-listing': return <AddListingPage onNav={navigate} />
      case 'edit-listing': return <AddListingPage onNav={navigate} />
      case 'gallery': return <GalleryPage />
      case 'reservations': return <ReservationsPage />
      case 'reviews': return <ReviewsPage />
      case 'analytics': return <AnalyticsPage />
      case 'promotions': return <PromotionsPage />
      case 'notifications': return <NotificationsPage />
      case 'reports': return <ReportsPage />
      case 'calendar': return <CalendarPage />
      case 'settings': return <SettingsPage />
      case 'help': return <HelpPage />
      default: return <DashboardPage onNav={navigate} />
    }
  }

  return (
    <div style={{ display: 'flex', height: '100vh', background: 'var(--background)', overflow: 'hidden' }}>
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex h-full flex-shrink-0" style={{ width: sidebarCollapsed ? 64 : 240, transition: 'width 0.3s ease' }}>
        <Sidebar current={page} onNav={navigate} collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />
      </div>

      {/* Mobile Sidebar Overlay */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60 animate-fade-in" onClick={() => setMobileMenuOpen(false)} />
          <div className="relative z-10 h-full animate-slide-in-left" style={{ width: 240 }}>
            <Sidebar current={page} onNav={navigate} collapsed={false} onToggle={() => setMobileMenuOpen(false)} />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        <AppBar page={page} onMobileMenu={() => setMobileMenuOpen(true)} notifCount={5} />
        <main
          style={{
            flex: 1,
            overflow: 'auto',
            padding: '24px',
            background: 'radial-gradient(ellipse at top right, rgba(249,115,22,0.04) 0%, transparent 60%), var(--background)',
          }}
        >
          {renderPage()}
        </main>
      </div>
    </div>
  )
}
